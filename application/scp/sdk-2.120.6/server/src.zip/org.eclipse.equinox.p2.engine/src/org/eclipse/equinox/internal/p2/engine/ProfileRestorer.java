package org.eclipse.equinox.internal.p2.engine;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.equinox.p2.core.IProvisioningAgent;
import org.eclipse.equinox.p2.core.ProvisionException;
import org.eclipse.equinox.p2.engine.IEngine;
import org.eclipse.equinox.p2.engine.IPhaseSet;
import org.eclipse.equinox.p2.engine.IProfile;
import org.eclipse.equinox.p2.engine.IProfileRegistry;
import org.eclipse.equinox.p2.engine.IProfileRestorer;
import org.eclipse.equinox.p2.engine.IProvisioningPlan;
import org.eclipse.equinox.p2.engine.PhaseSetFactory;
import org.eclipse.equinox.p2.engine.ProvisioningContext;
import org.eclipse.equinox.p2.metadata.IInstallableUnit;
import org.eclipse.equinox.p2.metadata.IProvidedCapability;
import org.eclipse.equinox.p2.metadata.IRequirement;
import org.eclipse.equinox.p2.metadata.ITouchpointType;
import org.eclipse.equinox.p2.metadata.MetadataFactory;
import org.eclipse.equinox.p2.metadata.Version;
import org.eclipse.equinox.p2.metadata.VersionRange;
import org.eclipse.equinox.p2.metadata.MetadataFactory.InstallableUnitDescription;
import org.eclipse.osgi.service.environment.EnvironmentInfo;
import org.eclipse.osgi.service.resolver.BundleDescription;
import org.eclipse.osgi.service.resolver.BundleSpecification;
import org.eclipse.osgi.service.resolver.ExportPackageDescription;
import org.eclipse.osgi.service.resolver.ImportPackageSpecification;
import org.eclipse.osgi.service.resolver.PlatformAdmin;
import org.eclipse.osgi.service.resolver.State;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.ServiceReference;

public class ProfileRestorer implements IProfileRestorer {
	private static final String CAPABILITY_NS_OSGI_BUNDLE = "osgi.bundle"; //$NON-NLS-1$
	private static final String CAPABILITY_NS_OSGI_FRAGMENT = "osgi.fragment"; //$NON-NLS-1$
	public static final ITouchpointType TOUCHPOINT_OSGI = MetadataFactory.createTouchpointType("org.eclipse.equinox.p2.osgi", Version.createOSGi(1, 0, 0)); //$NON-NLS-1$
	public static final String TYPE_ECLIPSE_BUNDLE = "bundle"; //$NON-NLS-1$
	public static final String NAMESPACE_ECLIPSE_TYPE = "org.eclipse.equinox.p2.eclipse.type"; //$NON-NLS-1$
	public static final IProvidedCapability BUNDLE_CAPABILITY = MetadataFactory.createProvidedCapability(NAMESPACE_ECLIPSE_TYPE, TYPE_ECLIPSE_BUNDLE, Version.createOSGi(1, 0, 0));
	public static final String CAPABILITY_NS_JAVA_PACKAGE = "java.package"; //$NON-NLS-1$
	private static final String OPTIONAL_INCLUSION_RULE = "OPTIONAL"; //$NON-NLS-1$
	private BundleContext context;
	
	
	
	public ProfileRestorer(BundleContext context) {
		super();
		this.context = context;
	}

	/* (non-Javadoc)
	 * @see updater.ProfileRestrorer#createProfile(org.osgi.framework.BundleContext, org.eclipse.equinox.p2.engine.IProfileRegistry, org.eclipse.equinox.p2.engine.IEngine, org.eclipse.equinox.p2.core.IProvisioningAgent)
	 */
	public void createProfile(IProvisioningAgent agent, String profileID, String destination, Properties profileProps) throws Exception {
//		// Delete any previous profiles with the same ID
		if (profileID == null || profileID.equals("")) {
			profileID = "SDKProfile";
		}
		
		
//		IProfile[] profiles = profileRegistry.getProfiles();
		 
		// Create the profile
		//get the system property for the location for the installation 
		IProfileRegistry profileRegistry = (IProfileRegistry)agent.getService(IProfileRegistry.SERVICE_NAME);

		if (profileRegistry == null) {
			throw new ProvisionException(IStatus.ERROR + " in profile restorer: unable to acquire p2 registry");
		}
		
		IProfile profile = profileRegistry.getProfile(profileID);
		if (profile != null) {
			return;
		}
		File installDir = new File(destination);
//		if(installDir.exists() && !installDir.getName().equals(".")) {
//			String[] files = installDir.list();
//			if(files.length > 0) {
//				throw new ProvisionException("Installation folder not empty. Currently only clean install is supported");
//			}
//		}
		
//		if(profiles.length == 0) {
		ServiceReference environmentInfo = context.getServiceReference(EnvironmentInfo.class.getName());
		EnvironmentInfo envInfo = null;
		if(environmentInfo != null) {
			envInfo = (EnvironmentInfo) context.getService(environmentInfo);
		}
		 
		
		Map <String,String> properties = new HashMap <String,String>();
		if(envInfo != null) {
			String osgiOs = envInfo.getOS();
			String osgiArch = envInfo.getOSArch();
			String osgiWs = envInfo.getProperty("osgi.ws");
		
			
			StringBuilder builder = new StringBuilder();
			builder.append("osgi.os=");
			builder.append(osgiOs);
			builder.append(",osgi.ws=");
			builder.append(osgiWs);
			builder.append(",osgi.arch=");
			builder.append(osgiArch);
			
			properties.put("org.eclipse.equinox.p2.environments", builder.toString());
			properties.put("org.eclipse.equinox.p2.installFolder",destination);
			properties.put("eclipse.p2.bundleLocation", destination);
			if (profileProps != null) {
				for(Object key : profileProps.keySet() ) {
					properties.put((String) key, profileProps.getProperty((String) key));
				}				
			}
			
			// properties.put("p2.mapping.rule.bundle","${repoUrl}/plugins/${id}.jar");

			Path path = new Path(properties.get("eclipse.p2.bundleLocation"));
			properties.put(IProfile.PROP_CACHE, path.toOSString());

		} else {
			throw new ProvisionException("Cannot get environment parameters");
		}
		
		if(!installDir.equals(".")) {
			try {
				profile = profileRegistry.addProfile(profileID, properties);
			} catch (ProvisionException e) {
				System.out.println("The current profile is null");
				e.printStackTrace();
			}
			return;
		}

		ServiceReference ref = context.getServiceReference(PlatformAdmin.class.getName());
		PlatformAdmin platformAdmin = null;
		if(ref != null) {
			platformAdmin = (PlatformAdmin)context.getService(ref);
		}
		if(platformAdmin == null) {
			throw new Exception(IStatus.ERROR + " in updater: unable to acquire platform admin");
		}
		try {

			profile =  profileRegistry.addProfile(profileID, properties);
			// Create metadata for the bundles
			State currentState = platformAdmin.getState();
			BundleDescription[] bundleDesriptions =currentState.getBundles();
			Collection ius = new ArrayList(bundleDesriptions.length);
			for (BundleDescription current : bundleDesriptions) {
				ius.add(createBundleIU(current));
			}

			// Add the metadata to the profile
			ProvisioningContext provisioningContext = new ProvisioningContext(agent);
			IEngine engine = (IEngine) agent.getService(IEngine.SERVICE_NAME);
			IProvisioningPlan plan = engine.createPlan(profile, provisioningContext);
			for (Iterator iter = ius.iterator(); iter.hasNext();) {
				IInstallableUnit iu = (IInstallableUnit) iter.next();
				plan.addInstallableUnit(iu);
				plan.setInstallableUnitProfileProperty(iu, "org.eclipse.equinox.p2.internal.inclusion.rules", OPTIONAL_INCLUSION_RULE); //$NON-NLS-1$
			}
			IPhaseSet phaseSet = PhaseSetFactory.createDefaultPhaseSetExcluding(new String[] {PhaseSetFactory.PHASE_CHECK_TRUST, PhaseSetFactory.PHASE_COLLECT, PhaseSetFactory.PHASE_CONFIGURE, PhaseSetFactory.PHASE_UNCONFIGURE, PhaseSetFactory.PHASE_UNINSTALL});
			IStatus status = engine.perform(plan, phaseSet, new NullProgressMonitor());

			if (!status.isOK() && status.getSeverity() != IStatus.CANCEL) {
				throw new Exception("Engine finished creating profile operation with unexpected result " + status);
			}

		} catch (ProvisionException e) {
			// TODO Auto-generated catch block
			System.out.println("The current profile is null");
			e.printStackTrace();
		}
	}
	
	/**
	 * Creates an installable unit from a bundle description
	 * 
	 * @param bd bundle description to create metadata for
	 * @return an installable unit
	 */
	private static IInstallableUnit createBundleIU(BundleDescription bd) {
		InstallableUnitDescription iu = new MetadataFactory.InstallableUnitDescription();
		iu.setSingleton(bd.isSingleton());
		iu.setId(bd.getSymbolicName());
		iu.setVersion(fromOSGiVersion(bd.getVersion()));
		iu.setFilter(bd.getPlatformFilter());
		iu.setTouchpointType(TOUCHPOINT_OSGI);

		boolean isFragment = bd.getHost() != null;

		//Process the required bundles
		BundleSpecification requiredBundles[] = bd.getRequiredBundles();
		ArrayList reqsDeps = new ArrayList();
		if (isFragment)
			reqsDeps.add(MetadataFactory.createRequirement(CAPABILITY_NS_OSGI_BUNDLE, bd.getHost().getName(), fromOSGiVersionRange(bd.getHost().getVersionRange()), null, false, false));
		for (int j = 0; j < requiredBundles.length; j++)
			reqsDeps.add(MetadataFactory.createRequirement(CAPABILITY_NS_OSGI_BUNDLE, requiredBundles[j].getName(), fromOSGiVersionRange(requiredBundles[j].getVersionRange()), null, requiredBundles[j].isOptional(), false));

		// Process the import packages
		ImportPackageSpecification osgiImports[] = bd.getImportPackages();
		for (int i = 0; i < osgiImports.length; i++) {
			// TODO we need to sort out how we want to handle wild-carded dynamic imports - for now we ignore them
			ImportPackageSpecification importSpec = osgiImports[i];
			String importPackageName = importSpec.getName();
			if (importPackageName.indexOf('*') != -1)
				continue;
			VersionRange versionRange = fromOSGiVersionRange(importSpec.getVersionRange());
			//TODO this needs to be refined to take into account all the attribute handled by imports
			boolean isOptional = importSpec.getDirective(Constants.RESOLUTION_DIRECTIVE).equals(ImportPackageSpecification.RESOLUTION_DYNAMIC) || importSpec.getDirective(Constants.RESOLUTION_DIRECTIVE).equals(ImportPackageSpecification.RESOLUTION_OPTIONAL);
			reqsDeps.add(MetadataFactory.createRequirement(CAPABILITY_NS_JAVA_PACKAGE, importPackageName, versionRange, null, isOptional, false));
		}
		iu.setRequiredCapabilities((IRequirement[]) reqsDeps.toArray(new IRequirement[reqsDeps.size()]));

		// Create set of provided capabilities
		ArrayList providedCapabilities = new ArrayList();
		providedCapabilities.add(MetadataFactory.createProvidedCapability(IInstallableUnit.NAMESPACE_IU_ID, bd.getSymbolicName(), fromOSGiVersion(bd.getVersion())));
		providedCapabilities.add(MetadataFactory.createProvidedCapability(CAPABILITY_NS_OSGI_BUNDLE, bd.getSymbolicName(), fromOSGiVersion(bd.getVersion())));

		// Process the export package
		ExportPackageDescription exports[] = bd.getExportPackages();
		for (int i = 0; i < exports.length; i++) {
			//TODO make sure that we support all the refinement on the exports
			providedCapabilities.add(MetadataFactory.createProvidedCapability(CAPABILITY_NS_JAVA_PACKAGE, exports[i].getName(), fromOSGiVersion(exports[i].getVersion())));
		}
		// Here we add a bundle capability to identify bundles
		providedCapabilities.add(BUNDLE_CAPABILITY);
		if (isFragment)
			providedCapabilities.add(MetadataFactory.createProvidedCapability(CAPABILITY_NS_OSGI_FRAGMENT, bd.getHost().getName(), fromOSGiVersion(bd.getVersion())));

		iu.setCapabilities((IProvidedCapability[]) providedCapabilities.toArray(new IProvidedCapability[providedCapabilities.size()]));
		return MetadataFactory.createInstallableUnit(iu);
	}
	
	private static Version fromOSGiVersion(org.osgi.framework.Version version) {
		if (version == null)
			return null;
		if (version.getMajor() == Integer.MAX_VALUE && version.getMicro() == Integer.MAX_VALUE && version.getMicro() == Integer.MAX_VALUE)
			return Version.MAX_VERSION;
		return Version.createOSGi(version.getMajor(), version.getMinor(), version.getMicro(), version.getQualifier());
	}

	private static VersionRange fromOSGiVersionRange(org.eclipse.osgi.service.resolver.VersionRange range) {
		if (range.equals(org.eclipse.osgi.service.resolver.VersionRange.emptyRange))
			return VersionRange.emptyRange;
		return new VersionRange(fromOSGiVersion(range.getMinimum()), range.getIncludeMinimum(), fromOSGiVersion(range.getMaximum()), range.getIncludeMaximum());
	}
}
