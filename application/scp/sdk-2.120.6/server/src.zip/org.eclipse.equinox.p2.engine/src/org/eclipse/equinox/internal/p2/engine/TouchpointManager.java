/*******************************************************************************
 *  Copyright (c) 2007, 2009 IBM Corporation and others.
 *  All rights reserved. This program and the accompanying materials
 *  are made available under the terms of the Eclipse Public License v1.0
 *  which accompanies this distribution, and is available at
 *  http://www.eclipse.org/legal/epl-v10.html
 * 
 *  Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.equinox.internal.p2.engine;

import java.util.HashMap;
import java.util.Map;
import org.eclipse.core.runtime.*;
import org.eclipse.equinox.internal.p2.core.helpers.LogHelper;
import org.eclipse.equinox.p2.engine.spi.Touchpoint;
import org.eclipse.equinox.p2.metadata.*;
import org.eclipse.osgi.util.NLS;
import org.osgi.framework.BundleContext;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceReference;

//TODO This needs to support multiple version of each touchpoint and have a lookup that supports version semantics
public class TouchpointManager  {

	private static final String ATTRIBUTE_TYPE = "type"; //$NON-NLS-1$
	private BundleContext bundleContext;


	public TouchpointManager(BundleContext context) {
		bundleContext = context;
	}
	
	public TouchpointManager() {
		bundleContext = null;
	}

	/*
	 * Return the touchpoint which is registered for the given type,
	 * or <code>null</code> if none are registered.
	 */
	public synchronized Touchpoint getTouchpoint(ITouchpointType type) {
		if (type == null)
			throw new IllegalArgumentException(Messages.TouchpointManager_Null_Touchpoint_Type_Argument);
		return getTouchpoint(type.getId(), type.getVersion().toString());
	}

	/*
	 * Return the touchpoint which is registered for the given type and optionally version,
	 * or <code>null</code> if none are registered.
	 */
	public Touchpoint getTouchpoint(String typeId, String versionRange) {
		if (typeId == null || typeId.length() == 0)
			throw new IllegalArgumentException(Messages.TouchpointManager_Null_Touchpoint_Type_Argument);
		ServiceReference[] touchPointRefs;
		try {
			touchPointRefs = bundleContext.getAllServiceReferences(Touchpoint.class.getName(), "(" + ATTRIBUTE_TYPE + "=" + typeId+ ")");
			if(touchPointRefs == null) {
				return null;
			}
			return (Touchpoint)bundleContext.getService(touchPointRefs[0]);
		} catch (InvalidSyntaxException e) {			
			e.printStackTrace();
			return null;
		}
		
		
	}

}
