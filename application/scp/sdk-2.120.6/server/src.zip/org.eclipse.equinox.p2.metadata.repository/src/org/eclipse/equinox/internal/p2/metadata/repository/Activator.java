/*******************************************************************************
 *  Copyright (c) 2007, 2009 IBM Corporation and others.
 *  All rights reserved. This program and the accompanying materials
 *  are made available under the terms of the Eclipse Public License v1.0
 *  which accompanies this distribution, and is available at
 *  http://www.eclipse.org/legal/epl-v10.html
 * 
 *  Contributors:
 *     IBM Corporation - initial API and implementation
 *     Cloudsmith Inc - additional implementation
 *******************************************************************************/
package org.eclipse.equinox.internal.p2.metadata.repository;

import java.util.Dictionary;
import java.util.Hashtable;

import org.eclipse.equinox.p2.core.spi.IAgentServiceFactory;
import org.eclipse.equinox.p2.repository.metadata.spi.MetadataRepositoryFactory;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class Activator implements BundleActivator {

	public static final String ID = "org.eclipse.equinox.p2.metadata.repository"; //$NON-NLS-1$

	private static BundleContext bundleContext;

	public static BundleContext getContext() {
		return bundleContext;
	}

	public void start(BundleContext aContext) throws Exception {
		bundleContext = aContext;
		{
			Dictionary prop = new Hashtable();
		    prop.put("p2.agent.servicename", "org.eclipse.equinox.p2.repository.metadata.IMetadataRepositoryManager");
		    aContext.registerService(IAgentServiceFactory.class.getName(), new MetadataRepositoryComponent(), prop);
			
		}
		
		{
			Dictionary prop = new Hashtable(2);
		    prop.put("suffix", "content.xml");
		    prop.put("type", "org.eclipse.equinox.p2.metadata.repository.simpleRepository");
		    aContext.registerService(MetadataRepositoryFactory.class.getName(), new SimpleMetadataRepositoryFactory(), prop);			
		}
		
		{
			Dictionary prop = new Hashtable(2);
		    prop.put("suffix", "compositeContent.xml");
		    prop.put("type", "org.eclipse.equinox.p2.metadata.repository.compositeRepository");
		    aContext.registerService(MetadataRepositoryFactory.class.getName(), new CompositeMetadataRepositoryFactory(), prop);			
		}
	}

	public void stop(BundleContext aContext) throws Exception {
		bundleContext = null;
	}
}
