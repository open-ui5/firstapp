package org.eclipse.equinox.p2.engine;

import java.util.Properties;

import org.eclipse.equinox.p2.core.IProvisioningAgent;


public interface IProfileRestorer {

	public void createProfile(IProvisioningAgent agent, String profileID, String destination, Properties profileProps) throws Exception;

}