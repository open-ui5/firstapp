/*******************************************************************************
 *  Copyright (c) 2008, 2009 IBM Corporation and others.
 *  All rights reserved. This program and the accompanying materials
 *  are made available under the terms of the Eclipse Public License v1.0
 *  which accompanies this distribution, and is available at
 *  http://www.eclipse.org/legal/epl-v10.html
 * 
 *  Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.equinox.internal.p2.engine;

import java.util.HashMap;
import java.util.Map;
import org.eclipse.core.runtime.*;
import org.eclipse.equinox.internal.p2.core.helpers.LogHelper;
import org.eclipse.equinox.p2.engine.spi.ProvisioningAction;
import org.eclipse.equinox.p2.engine.spi.Touchpoint;
import org.eclipse.equinox.p2.metadata.ITouchpointType;
import org.eclipse.equinox.p2.metadata.VersionRange;
import org.eclipse.osgi.util.NLS;
import org.osgi.framework.BundleContext;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceReference;

public class ActionManager  {

	private static final String PT_ACTIONS = "actions"; //$NON-NLS-1$
	private static final String ELEMENT_ACTION = "action"; //$NON-NLS-1$
	private static final String ATTRIBUTE_CLASS = "class"; //$NON-NLS-1$
	private static final String ATTRIBUTE_NAME = "name"; //$NON-NLS-1$
	public static final String TOUCHPOINT_TYPE = "touchpointType"; //$NON-NLS-1$
	public static final String TOUCHPOINT_VERSION = "touchpointVersion"; //$NON-NLS-1$
	/**
	 * Service name constant for the action manager service. This service is used internally
	 * by the engine implementation and should not be referenced directly by clients.
	 */
	public static final String SERVICE_NAME = ActionManager.class.getName();

	private TouchpointManager touchpointManager;
	private BundleContext bundleContext;
	
	public ActionManager(BundleContext context) {
		bundleContext = context;
		this.touchpointManager = new TouchpointManager(bundleContext);
	}

	public Touchpoint getTouchpointPoint(ITouchpointType type) {
		if (type == null || type == ITouchpointType.NONE)
			return null;
		return touchpointManager.getTouchpoint(type);
	}

	public String getTouchpointQualifiedActionId(String actionId, ITouchpointType type) {
		if (actionId.indexOf('.') == -1) {
			if (type == null || type == ITouchpointType.NONE)
				return actionId;

			Touchpoint touchpoint = touchpointManager.getTouchpoint(type);
			if (touchpoint == null)
				throw new IllegalArgumentException(NLS.bind(Messages.ActionManager_Required_Touchpoint_Not_Found, type.toString(), actionId));
			actionId = touchpoint.qualifyAction(actionId);
		}
		return actionId;
	}

	public ProvisioningAction getAction(String actionId, VersionRange versionRange) {
		
		ServiceReference[] actionRefs;
		try {
			//TODO: constant
			actionRefs = bundleContext.getAllServiceReferences(ProvisioningAction.class.getName(), "(ID=" + actionId + ")");
			if(actionRefs == null) {
				return null;
			}
			ProvisioningAction action =  (ProvisioningAction)bundleContext.getService(actionRefs[0]);
			
			String touchpointType = (String )actionRefs[0].getProperty(TOUCHPOINT_TYPE);
			if (touchpointType != null) {
				String touchpointVersion = (String)actionRefs[0].getProperty(TOUCHPOINT_VERSION);
				Touchpoint touchpoint = touchpointManager.getTouchpoint(touchpointType, touchpointVersion);
				if (touchpoint == null)
					throw new IllegalArgumentException(NLS.bind(Messages.ActionManager_Required_Touchpoint_Not_Found, touchpointType, actionId));
				action.setTouchpoint(touchpoint);
			}
			return action;
		} catch (InvalidSyntaxException e) {			
			e.printStackTrace();
			return null;
		}			
	}
	
	static void reportError(String errorMsg) {
		Status errorStatus = new Status(IStatus.ERROR, EngineActivator.ID, 1, errorMsg, null);
		LogHelper.log(errorStatus);
	}

}
